/*
	Name:			mx_init_hw.c
	Purpose:		IO module
	Author:			www.open-plc.com; e-mail: info@open-plc.com
	Created:		2018/07
	Modified by:
	RCS-ID:
	Copyright:		(c) Open-PLC
	Licence:		The MIT License (MIT)
*/

#include <stm32f10x.h>
#include <stm32f10x_rcc.h>
#include <stm32f10x_iwdg.h>
#include <stm32f10x_exti.h>
#include <stm32f10x_gpio.h>
#include <stm32f10x_usart.h>
#include <stm32f10x_tim.h>
#include <stm32f10x_adc.h>
#include <stm32f10x_dma.h>
#include <stm32f10x_dac.h>
#include <stm32f10x_flash.h>
#include <stm32f10x_i2c.h>

#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

#include "gbl.h"
#include "mx_misc.c"
#include "mx_init.c"
#include "mx_parcer.c"
#include "mx_cli.c"

/* --- external CAN MCP2515 --- */
#ifdef CAN_2515
	#include "mx_spi.c"
	#include "mx_can_mcp2515.c"
#endif

#include "mx_io.c"
//#include "mx_adc.c"
#include "mx_timers.c"

#ifdef LCD_1602
#include "mx_i2c1.c"
#include "mx_lcd_i2c.c"		// lcd 1602 / i2c; #define LCD_I2C
#else
void LCD_write_string( uint16_t n, char *str ) {}
#endif

/* --- USB --- */
#ifndef USB_VCP
void send_usb( char *data, int len );
#else
		#include "hw_config.h"
	#include "usb_lib.h"
	#include "usb_desc.h"
	#include "usb_pwr.h"
#endif
	#include "../usb/src/usb_endp.c"	// Comment if full delete USB support


// ===========================================================================
void Init_HW( void )
// ===========================================================================
{
	int		i, j;
//	char	s[128];

	SystemInit();
	Read_Flash();

	// Clear channels present in the reserved list
	for( i = 0; i < Nn_Ch; i++ )
	{
		for( j = 0; j < MAX_NN_CH; j++ )
		{
			if( ( GPIO_X[i].gpio_x == Reserved_Ch[j].gpio_x ) && ( GPIO_X[i].gpio_pin_nn == Reserved_Ch[j].gpio_pin_nn ) )
			{
				GPIO_X[i].gpio_x		= 0;
				GPIO_X[i].gpio_pin_nn	= 0;
				GPIO_X[i].dev_type		= 0;
			}
		}
	}

	MX_Init();

	sys_delay_ms( 100 );

	// --- USE_UART1 ---------------------------------------------------------
	#ifdef USE_UART1
		USART_ClearITPendingBit( USART1, USART_IT_RXNE );	// Clear UART
		print_str( "+++\r\n" );
	#endif

	// --- CAN_2515 ----------------------------------------------------------
	#ifdef CAN_2515
		Init_Spi();
		reset_can();
		delay_us( 100 );
		Init_Can();
	#endif

	// --- USB_VC ------------------------------------------------------------
	#ifdef USB_VCP
		sys_delay_ms( 2000 );
		USB_Interrupts_Config();
		sys_delay_ms( 1000 );
		USB_Init();
		sys_delay_ms( 1000 );
		print_str( "+++\r\n" );
	#endif

	Init_Timer3();		//
	Init_Timer4();		//

	// --- ADC ---------------------------------------------------------------
//	Init_ADC();			// Init ADC as DMA

	// --- LCD_1602 ----------------------------------------------------------
	#ifdef LCD_1602		// Init LCD 1602
		#ifdef PCF8574
			#define PCF8574_ADDR 0x27
		#endif
		#ifdef PCF8574A
			#define PCF8574_ADDR 0x3F
		#endif
		LCDI2C_init( PCF8574_ADDR, 20, 4 );
		while( I2C1_ERR && ( I2C1_ERR < 3 ) )
		{
			LCDI2C_init( PCF8574_ADDR, 20, 4 );
		}
		if( !I2C1_ERR )
		{
			LCDI2C_backlight();		// finish with backlight on
		}
		init_lcd1();
	#endif
}
// ===========================================================================

#ifndef __PLATFORM_CONFIG_H
#define __PLATFORM_CONFIG_H

#include "stm32f30x.h"
#include "stm32f30x_gpio.h"
#include "stm32f30x_rcc.h"
#include "stm32f30x_usart.h"
#include "stm32f30x_syscfg.h"
#include "stm32f30x_pwr.h"
#include "stm32f30x_exti.h"
#include "stm32f30x_misc.h"

#define		ID1		(0x1FFFF7AC)
#define		ID2		(0x1FFFF7B0)
#define		ID3		(0x1FFFF7B4)

#endif /* __PLATFORM_CONFIG_H */

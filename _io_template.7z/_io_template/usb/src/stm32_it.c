#include "hw_config.h"
#include "stm32_it.h"
#include "usb_lib.h"
#include "usb_istr.h"


void NMI_Handler( void ) {}                         // NMI exception
void HardFault_Handler( void ) { while (1) {} }     // Hard Fault exception
void MemManage_Handler( void ) { while(1) {} }      // Memory Manage exception
void BusFault_Handler( void ) { while(1) {} }       // Bus Fault exception
void UsageFault_Handler( void ) { while(1) {} }     // Usage Fault exception
void SVC_Handler( void ) {}                         // SVCall exception
void DebugMon_Handler( void ) {}                    // Debug Monitor exception
void PendSV_Handler( void ) {}                      // PendSVC exception

// USB Low Priority interrupts
#if defined(STM32L1XX_MD) || defined(STM32L1XX_HD)|| defined(STM32L1XX_MD_PLUS)|| defined (STM32F37X)
    void USB_LP_IRQHandler( void )
#else
    void USB_LP_CAN1_RX0_IRQHandler( void )
#endif
{ USB_Istr(); }

#if defined(STM32L1XX_MD) || defined(STM32L1XX_HD)|| defined(STM32L1XX_MD_PLUS)
    void USB_FS_WKUP_IRQHandler( void )
#else
    void USBWakeUp_IRQHandler(void)
#endif
{ EXTI_ClearITPendingBit( EXTI_Line18 ); }

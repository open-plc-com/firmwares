/*
	Name:			mx_init_hw.c
	Purpose:		IO module
	Author:			www.open-plc.com
	Created:		2018/12
	Modified by:
	RCS-ID:
	Copyright:		(c) Open-PLC
	Licence:		The MIT License (MIT)
*/

#include "stm32f30x.h"
#include "stm32f30x_rcc.h"
#include "stm32f30x_iwdg.h"
#include "stm32f30x_exti.h"
#include "stm32f30x_gpio.h"
#include "stm32f30x_usart.h"
#include "stm32f30x_tim.h"
#include "stm32f30x_adc.h"
#include "stm32f30x_dma.h"
#include "stm32f30x_dac.h"
#include "stm32f30x_flash.h"
#include "stm32f30x_i2c.h"
#include "stm32f30x_spi.h"

//#include "stm32f30x_can.h"
//#include "stm32f30x_comp.h"
//#include "stm32f30x_crc.h"
//#include "stm32f30x_dbgmcu.h"
//#include "stm32f30x_fmc.h"
//#include "stm32f30x_hrtim.h"
//#include "stm32f30x_misc.h"
//#include "stm32f30x_opamp.h"
//#include "stm32f30x_pwr.h"
//#include "stm32f30x_rtc.h"
//#include "stm32f30x_syscfg.h"
//#include "stm32f30x_wwdg.h"

#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

#include "gbl.h"
#include "mx_misc.c"
#include "mx_init.c"
#include "mx_parcer.c"
#include "mx_flash.c"
#include "mx_cli.c"
#include "mx_io.c"
#include "mx_timers.c"
#include "mx_adc.c"

/* --- external CAN MCP2515 --- */
#ifdef CAN_2515
	#include "mx_spi_mcp2515.c"
	#include "mx_can_mcp2515.c"
#endif

#ifdef LCD_1602
	#include "mx_i2c1.c"
	#include "mx_lcd_i2c.c"		// lcd 1602 / i2c; #define LCD_I2C
#else
	void LCD_write_string( uint16_t n, char *str ) {}
//{
//print_str( str );
//print_str( "\r\n" );
//}
#endif

/* --- USB --- */
#ifndef USB_VCP
void send_usb( char *data, int len );
#else
	#include "hw_config.h"
	#include "usb_lib.h"
	#include "usb_desc.h"
	#include "usb_pwr.h"
#endif
	#include "../usb/src/usb_endp.c"	// Comment if full delete USB support


// ===========================================================================
void Init_HW( void )
// ===========================================================================
{
	int		i, j;
	GPIO_InitTypeDef	GPIO_InitStructure;

	SystemInit();
	clr_input();
	NVIC_PriorityGroupConfig( NVIC_PriorityGroup_3 );

	RCC_APB1PeriphClockCmd( RCC_APB1Periph_PWR, ENABLE );
	PWR_BackupAccessCmd( ENABLE );
	RCC_RTCCLKConfig( RCC_RTCCLKSource_LSE );
	RCC_RTCCLKCmd( ENABLE );

	#ifdef USB_VCP
		RCC_AHBPeriphClockCmd( RCC_AHBPeriph_GPIOA, ENABLE );	// Clocking GPIOA
		i = RTC_ReadBackupRegister( RTC_BKP_DR15 );
		if( i == 0 )
		{
			GPIO_StructInit( &GPIO_InitStructure );
			GPIO_InitStructure.GPIO_Pin		= GPIO_Pin_12;
			GPIO_InitStructure.GPIO_OType	= GPIO_OType_PP;
			GPIO_InitStructure.GPIO_Speed	= GPIO_Speed_2MHz;
			GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_OUT;
			GPIO_InitStructure.GPIO_PuPd	= GPIO_PuPd_NOPULL;
			GPIO_Init( GPIOA, &GPIO_InitStructure );

			GPIO_ResetBits( GPIOA, GPIO_Pin_12 );
			delay_ms( 1000 );
			GPIO_SetBits( GPIOA, GPIO_Pin_12 );
		}

		Set_System();
		Set_USBClock();
		USB_Interrupts_Config();
		USB_Init();
		delay_ms( 1000 );
	#endif

	Read_Flash();
	MX_Init();

	#ifdef CAN_2515
		Init_Spi();
		Reset_Can();
		delay_us( 100 );
		Init_Can();
	#endif

	Init_Timer2();
	Init_Timer3();	// CLI; Read_Data; Print_Data
	Init_Timer4();	// ADC

//print_str( "adc_1\r\n" );
	Init_ADC();		// Init ADC as DMA
//print_str( "adc_2\r\n" );

	#ifdef LCD_1602		// Init LCD 1602
		#ifdef PCF8574
			#define PCF8574_ADDR 0x27
		#endif
		#ifdef PCF8574A
			#define PCF8574_ADDR 0x3F
		#endif
		LCDI2C_init( PCF8574_ADDR, 20, 2 );
		LCDI2C_init( PCF8574_ADDR, 20, 2 );
		LCDI2C_backlight();		// finish with backlight on
	#endif
}
// ===========================================================================

/*
	Name:			mx_timers.c
	Purpose:		IO module
	Author:			www.open-plc.com
	Created:		2018/12
	Modified by:
	RCS-ID:
	Copyright:		(c) Open-PLC
	Licence:		The MIT License (MIT)
*/


// ===========================================================================
void Init_Timer2( void )
// ===========================================================================
{
	NVIC_InitTypeDef			NVIC_InitStructure;
	TIM_TimeBaseInitTypeDef		TIMER_InitStructure;

	RCC_APB1PeriphClockCmd( RCC_APB1Periph_TIM2, ENABLE );	// Clocking TIM2

	TIM_TimeBaseStructInit( &TIMER_InitStructure );
	TIMER_InitStructure.TIM_CounterMode		= TIM_CounterMode_Up;
	TIMER_InitStructure.TIM_Prescaler		= 7200;
	TIMER_InitStructure.TIM_Period			= 10;
	TIM_TimeBaseInit( TIM2, &TIMER_InitStructure );
	TIM_ITConfig( TIM2, TIM_IT_Update, ENABLE );
	TIM_Cmd( TIM2, ENABLE );

	// NVIC Configuration
	NVIC_InitStructure.NVIC_IRQChannel						= TIM2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority	= 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority			= 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd					= ENABLE;
	NVIC_Init( &NVIC_InitStructure );
}
// ===========================================================================


// ===========================================================================
void Init_Timer3( void )
// ===========================================================================
{
	NVIC_InitTypeDef			NVIC_InitStructure;
	TIM_TimeBaseInitTypeDef		TIMER_InitStructure;

	RCC_APB1PeriphClockCmd( RCC_APB1Periph_TIM3, ENABLE );	// Clocking TIM3

	TIM_TimeBaseStructInit( &TIMER_InitStructure );
	TIMER_InitStructure.TIM_CounterMode		= TIM_CounterMode_Up;
	TIMER_InitStructure.TIM_Prescaler		= 7200;
	TIMER_InitStructure.TIM_Period			= 10;
	TIM_TimeBaseInit( TIM3, &TIMER_InitStructure );
	TIM_ITConfig( TIM3, TIM_IT_Update, ENABLE );
	TIM_Cmd( TIM3, ENABLE );

	// NVIC Configuration
	NVIC_InitStructure.NVIC_IRQChannel						= TIM3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority	= 3;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority			= 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd					= ENABLE;
	NVIC_Init( &NVIC_InitStructure );
}
// ===========================================================================


// ===========================================================================
void Init_Timer4( void )
// ===========================================================================
{
	NVIC_InitTypeDef			NVIC_InitStructure;
	TIM_TimeBaseInitTypeDef		TIMER_InitStructure;

	RCC_APB1PeriphClockCmd( RCC_APB1Periph_TIM4, ENABLE );	// Clocking TIM4

	TIM_TimeBaseStructInit( &TIMER_InitStructure );
	TIMER_InitStructure.TIM_CounterMode		= TIM_CounterMode_Up;
	TIMER_InitStructure.TIM_Prescaler		= 7200;
	TIMER_InitStructure.TIM_Period			= 10;
	TIM_TimeBaseInit( TIM4, &TIMER_InitStructure );
	TIM_ITConfig( TIM4, TIM_IT_Update, ENABLE );
	TIM_Cmd( TIM4, ENABLE );

	// NVIC Configuration
	NVIC_InitStructure.NVIC_IRQChannel						= TIM4_IRQn;
	//NVIC_PriorityGroupConfig( NVIC_PriorityGroup_4 );
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority	= 4;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority			= 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd					= ENABLE;
	NVIC_Init( &NVIC_InitStructure );
}
// ===========================================================================


// ===========================================================================
void TIM2_IRQHandler( void )
// ===========================================================================
{

//	TIM_Cmd( TIM2, DISABLE );

//t2 = DWT_CYCCNT - t1;
//t1 = DWT_CYCCNT;

	#ifdef WD_TIMER
		if( WD_Time++ > 15 )
		{
			WD_Time = 0;
			IWDG_ReloadCounter();
		}
	#endif

	if( TIM_GetITStatus( TIM2, TIM_IT_Update ) != RESET )
	{
		TIM_ClearITPendingBit( TIM2, TIM_IT_Update );
	}
//	TIM_Cmd( TIM2, ENABLE );
}
// ===========================================================================


// ===========================================================================
void TIM3_IRQHandler( void )	// CLI; Read_Data; Print_Data
// ===========================================================================
{
//t2 = DWT_CYCCNT - t1;
//t1 = DWT_CYCCNT;

	TIM_Cmd( TIM3, DISABLE );

//	if( usart_rx_data[0] == 'd' )
//	{
//		usart_rx_data[0] = 0;
//		rx_idx = 0;
//		USB_Delay = 10;
//	}

//	if( usart_rx_data[0] == 's' )
//	{
//		USB_Delay = 1000;
//		usart_rx_data[0] = 0;
//		rx_idx = 0;
//	}

	Cli_State();
	if( cli_mode )
	{
	//TIM_Cmd( TIM4, DISABLE );
		#ifdef LED_BLINK
			GPIOC->ODR = !GPIO_Pin_13;	// LED on
		#endif

//		USB_Delay = 1000;
		Cli();	// CLI mode

		#ifdef LED_BLINK
			GPIOC->ODR = GPIO_Pin_13;	// LED on
		#endif
	//TIM_Cmd( TIM4, ENABLE );
	}

	Read_Data();
	if( Show_Data ) { Print_Data(); }

	if( TIM_GetITStatus( TIM3, TIM_IT_Update ) != RESET )
	{
		TIM_ClearITPendingBit( TIM3, TIM_IT_Update );
	}
	TIM_Cmd( TIM3, ENABLE );
}
// ===========================================================================


// ===========================================================================
void TIM4_IRQHandler( void )	// ADC
// ===========================================================================
{
	//int	i, j, k, k1, k2, k_min, k_max;
//	int	level_0 = 470;
uint16_t buf[ADC_ARRAY_SIZE];
char s[128];
uint16_t **v;
uint32_t sum1, sum2, nn1, nn2, i;

//v = ( uint16_t** ) &ADC_VALUES[0];

t4 = DWT_CYCCNT - t3;
t3 = DWT_CYCCNT;



	//DMA_Cmd( DMA1_Channel1, DISABLE );
	TIM_Cmd( TIM4, DISABLE );

CntTime_1ms++;

//


if( !cli_mode )
{

//ADC_Result[0] = ADC_GetConversionValue(ADC2);
kkk = 0;
for( i = 0; i < ADC_ARRAY_SIZE; i++ )
{
if( !( ADC_VALUES[i] & 0x8000 ) )
{
buf[i] = ADC_VALUES[i];
ADC_VALUES[i] = 0xFFFF;
//kkk++;
}
else
{
kkk++;
//ADC_VALUES[i] = 0xFFFF;
}
}









//sum1 = 0;
//sum2 = 0;
//nn1 = 0;
//nn2 = 0;
//for( i = 0; i < ADC_ARRAY_SIZE; i++ )
//{
//if( !( ADC_VALUES[i] & 0x8000 ) )
////if( !( v[i][0] & 0x8000 ) )
//{
//if( i & 1 )
//{
//sum2 += ADC_VALUES[i];
//nn2++;
//}
//else
//{
//sum1 += ADC_VALUES[i];
//nn1++;
//}
//ADC_VALUES[i] = 0xFFFF;
////v[i][0] = 0xFFFF;
//}
//}
//sum1 /= nn1;
//sum2 /= nn2;
//
//ADCV1 = sum1;
//ADCV2 = sum2;


//sprintf( s, "%d %d   \r", sum1, sum2 ); print_str( s );


	//Read_Data();
	//if( Show_Data ) { Print_Data(); }

}

//	#ifdef WD_TIMER
////print_str( "ttt\r\n" );
//	if( WD_Time++ > 150 )
//	{
////print_str( "ttt\r\n" );
//		WD_Time = 0;
//		IWDG_ReloadCounter();
//	}
//	#endif

	if( TIM_GetITStatus( TIM4, TIM_IT_Update ) != RESET )
	{
		TIM_ClearITPendingBit( TIM4, TIM_IT_Update );
		//GPIOA->ODR ^= GPIO_Pin_5;		// for debug
	}
	//DMA_Cmd( DMA1_Channel1, ENABLE );
	TIM_Cmd( TIM4, ENABLE );
}
// ===========================================================================

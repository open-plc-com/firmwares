/*
	Purpose:		IO module
	Author:			www.open-plc.com; e-mail: info@open-plc.com
	Created:		2018/07
	Modified by:
	RCS-ID:
	Copyright:		(c) Open-PLC
	Licence:		The MIT License (MIT)
*/

#ifdef LCD_1602

I2C_InitTypeDef			i2c1;
//static volatile int		I2C1_ERR = 0;

// ===========================================================================
void init_I2C1( void )
// ===========================================================================
{
	GPIO_InitTypeDef	i2c_gpio;
	I2C_InitTypeDef		i2c_init;

	// --- I2C1 ---
	// PB6 - SCL
	// PB7 - SDA
	// ------------

	RCC_AHBPeriphClockCmd( RCC_AHBPeriph_GPIOB, ENABLE );
	RCC_APB1PeriphClockCmd( RCC_APB1Periph_I2C1, ENABLE );
	RCC_I2CCLKConfig( RCC_I2C1CLK_SYSCLK );

	GPIO_PinAFConfig( GPIOB, GPIO_PinSource6, GPIO_AF_4 );
	GPIO_PinAFConfig( GPIOB, GPIO_PinSource7, GPIO_AF_4 );

	GPIO_StructInit( &i2c_gpio );
	i2c_gpio.GPIO_Pin		= GPIO_Pin_6 | GPIO_Pin_7;
	i2c_gpio.GPIO_Speed		= GPIO_Speed_2MHz;
	i2c_gpio.GPIO_Mode		= GPIO_Mode_AF;
	i2c_gpio.GPIO_OType		= GPIO_OType_OD;
	i2c_gpio.GPIO_PuPd		= GPIO_PuPd_UP;
	GPIO_Init( GPIOB, &i2c_gpio );

	I2C_DeInit( I2C1 );
	i2c_init.I2C_Timing					= 0x10808DD3;
	i2c_init.I2C_Mode					= I2C_Mode_I2C;
	i2c_init.I2C_AnalogFilter			= I2C_AnalogFilter_Enable;
	i2c_init.I2C_DigitalFilter			= 0;
	i2c_init.I2C_OwnAddress1			= 0;
	i2c_init.I2C_Ack					= I2C_Ack_Enable;
	i2c_init.I2C_AcknowledgedAddress	= I2C_AcknowledgedAddress_7bit;
	I2C_Init( I2C1, &i2c_init );
	I2C_Cmd( I2C1, ENABLE );
}
// ===========================================================================


// ===========================================================================
uint8_t I2C_WriteByte( I2C_TypeDef *I2Cx, uint8_t slave_addr, uint8_t data )
// ===========================================================================
{
	uint8_t		addr = ( slave_addr & 0x7f ) << 1;
	uint8_t		count = 0;

	I2Cx->CR2 &= ~I2C_CR2_RD_WRN;
	I2Cx->CR2 &= ~I2C_CR2_NBYTES;
	I2Cx->CR2 |= 1 << 0x10;
	I2Cx->CR2 &= ~I2C_CR2_SADD;
	I2Cx->CR2 |= addr;
	I2Cx->CR2 |= I2C_CR2_START;

	while( ( I2Cx->ISR & I2C_ISR_BUSY ) == 0 ) {}

	while( ( ( ( I2Cx->ISR & I2C_ISR_TXIS ) == 0 ) && \
			 ( ( I2Cx->ISR & I2C_ISR_NACKF ) == 0 ) ) && \
		   ( I2Cx->ISR & I2C_ISR_BUSY ) ) {}

	if( I2Cx->ISR & I2C_ISR_TXIS )
	{
		I2Cx->TXDR = data;
		count = 1;
	}

	I2Cx->CR2 |= I2C_CR2_STOP;

	while( I2Cx->ISR & I2C_ISR_BUSY ) {}

	I2Cx->ICR |= I2C_ICR_STOPCF;
	I2Cx->ICR |= I2C_ICR_NACKCF;

	if( I2Cx->ISR & ( I2C_ISR_ARLO | I2C_ISR_BERR ) )
	{
		I2Cx->ICR |= I2C_ICR_ARLOCF;
		I2Cx->ICR |= I2C_ICR_BERRCF;
	}

	if( count ) { return 0; } return 1;
}
// ===========================================================================


// ===========================================================================
uint8_t I2C_ReadData( I2C_TypeDef *I2Cx )
// ===========================================================================
{
// ...
	return 0;
}
// ===========================================================================

#endif

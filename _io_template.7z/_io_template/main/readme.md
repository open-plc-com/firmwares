Functions:
----------

  delay_us( uint32_t delay )			- delay in a microseconds
  delay_ms( uint32_t delay )			- delay in a milliseconds

  print_str( char *str )				- print string to Console
										  str - string for print

  send_uart1( char *str, int n )		- send data to UART1
										  str - string for print
										  n - count of charters

  send_usb( char *str, int n )			- send data to USB/VCP
										  str - string for print
										  n - count of charters

  LCD_write_string( int n, char *str )	- write string to LCD 1602/I2C
										  n - string number ( 1, 2 )
										  str - string for print

  uint64_t read_ch( int nn )			- read data from ch
										  nn - number of channel
										  return unsigned int64
										  if error, then return 0xFFFFFFFFFFFFFFFF

  int write_ch( int ch, int value )		- write data to ch
										  nn - number of channel
										  if error, then return 1

Global variables:
  CntTime								- counter 10 mS in SysTick Nvic

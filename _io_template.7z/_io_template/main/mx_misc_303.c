/*
	Name:			mx_misc.c
	Purpose:		IO module
	Author:			www.open-plc.com
	Created:		201x
	Modified by:
	RCS-ID:
	Copyright:		(c) Open-PLC
	Licence:		The MIT License (MIT)
*/

#include "mx_misc.h"
#include "bsp_def.h"


void reset_can( void );
void Init_Can( void );
#ifdef USB_VCP
void send_usb( char *data, int len );
#endif

// ===========================================================================
void sys_delay_ms( uint32_t delay )		// Delay in milliseconds
// ===========================================================================
{
	volatile uint32_t	i;

	for( i = 0; i < delay; i++ )
	{
		sys_delay_us( 1000 );
	}
}
// ===========================================================================


// ===========================================================================
void sys_delay_us( uint32_t delay )		// Delay in microseconds
// ===========================================================================
{
	volatile uint32_t	cnt;

	cnt			= F_DWT;
	cnt			*= delay;
	//cnt		+= DWT_CYCCNT;
	DWT_CYCCNT	= 0;
	while( DWT_CYCCNT < cnt ) {}
}
// ===========================================================================


// ===========================================================================
void delay_ms( uint32_t delay )		// Delay in milliseconds
// ===========================================================================
{
	volatile uint32_t	i;

	i = ( F_APB1 / 72000 ) * delay;
	for( ; i != 0; i-- ) {}
}
// ===========================================================================


// ===========================================================================
void delay_us( uint32_t delay )		// Delay in microseconds
// ===========================================================================
{
	volatile uint32_t i;

	i = ( F_APB1 / 72000000 ) * delay;
	for( ; i != 0; i-- ) {}
}
// ===========================================================================


// ===========================================================================
void send_uart1( char *data, int len )	// Print str to USART1; without interrupt
// ===========================================================================
{
	int		i;
	#ifdef USE_UART1
		//while( !( USART1->SR & USART_SR_TC ) ) {}
		for( i = 0; i < len; i++ )
		{
			//while( !( USART1->SR & USART_SR_TC ) ) {}
			//USART1->DR = data[i];
		}
	#endif
}
// ===========================================================================


// ===========================================================================
void print_str( char *str )		// Print str to console
// ===========================================================================
{
	#ifdef USE_UART1
		#ifndef VCP_CONS
			int		i, n;
			n = strlen( str );
			for( i = 0; i < n; i++ )
			{
				USART_SendData( USART1, ( uint16_t ) str[i] );
				while( USART_GetFlagStatus( USART1, USART_FLAG_TXE ) == RESET ) {}
			}
		#endif
	#endif
	#ifdef USB_VCP
		#ifdef VCP_CONS
			int		i, n, n1, n2;
			char	s[64];
			//int		m;
			n = strlen( str );

if( n <= 60 )
{
send_usb( str, n );
}
else
{
for( i = 0; i < 60; i++ )
{
s[i] = str[i];
}
s[i] = 0;
n1 = strlen( s );
send_usb( s, n1 );
if( n >= 120 )
{
n = 120;
}
//if( ( n > 60 ) && ( n <= 120 ) )
//{
n1 = n - 60;
	//n2 = 63;
for( i = 0; i < n1; i++ )
{
s[i] = str[i+60];
}
s[i] = 0;
n1 = strlen( s );
send_usb( s, n1 );

//}
}

//if( n )
//{
//s[1] = 0;
//for( i = 0; i < n; i++ )
//{
//s[0] = str[i];
//send_usb( s, 1 );
//}
//}
		#endif
	#endif
}
// ===========================================================================


// ===========================================================================
void clr_input( void )
// ===========================================================================
{
	int i;

	for( i = 0; i < RX_LEN; i++ )
	{
		usart_rx_data[i] = 0;
	}
	ret_button = FALSE;
	rx_idx = 0;
}
// ===========================================================================


// ===========================================================================
#ifdef USE_UART1
void USART1_IRQHandler( void )	// USART1 IRQ Handler
// ===========================================================================
{
	#ifndef VCP_CONS	// UART1 as console
		char	c, s[2];
//print_str( "!" );
		// Interruption is caused by receive data
//		if (USART_GetITStatus( USART1, USART_IT_RXNE ) != RESET) // Received character?
		if( USART_GetITStatus( USART1, USART_IT_RXNE ) != RESET )	// Received character?
		{	
			c = USART_ReceiveData( USART1 );		// Read char
			s[0] = c;								// Put char to buffer for "echo"
			s[1] = 0;								// End of string

//print_str( s );

			if( c == 13 )
			{
				// if( rx_idx == 0 )
				usart_rx_data[rx_idx] = 0;
				ret_button = TRUE;					// Set flag "press Enter"
				rx_idx = 0;
			}
			else
			{
				if( rx_idx < ( RX_LEN - 1 ) )
				{
					usart_rx_data[rx_idx++] = c;	// Char to read buffer
					usart_rx_data[rx_idx] = 0;		// End of string
					if( Echo )
					{
						print_str( s );				// Echo
					}
				}
			}
			//USART_ClearITPendingBit( USART1, USART_IT_RXNE );
		}
	#else		// If UART1 not console
		char	c;
		if ( USART_GetITStatus( USART1, USART_IT_RXNE ) != RESET )
		{	
			c = USART_ReceiveData( USART1 );
			// ...
			USART_ClearITPendingBit( USART1, USART_IT_RXNE );
		}

	#endif
}
#endif
// ===========================================================================


// ===========================================================================
void SysTick_Handler( void )	// Priority = 7,0;  Frequency = 100 Hz
// ===========================================================================
{
//uint32_t	i;

	#ifdef LED_BLINK
	if( DelayTime )
	{
		DelayTime--;
	}
	else
	{
		//if( cli_mode )
		//{
			//DelayTime = 25;
		//}
		//else
		//{
			DelayTime = 75;
		//}
			GPIOC->ODR ^= GPIO_Pin_13;
	}
	#endif

	CntTime++;

	CANDownTime++;
	#ifdef CAN_2515
	if( CANDownTime > 500 )
	{
//print_str( "reset CAN 1\r\n" );
		reset_can();
//print_str( "reset CAN 2\r\n" );
		delay_us( 100 );
//print_str( "reset CAN 3\r\n" );
		Init_Can();
		CANDownTime = 0;
//print_str( "reset CAN 4\r\n" );
	}
	#endif

	#ifdef WD_TIMER
	if( WD_Time++ > 20 )
	{
//print_str( "reset WD\r\n" );
		WD_Time = 0;
		IWDG_ReloadCounter();
	}
	#endif
}
// ===========================================================================

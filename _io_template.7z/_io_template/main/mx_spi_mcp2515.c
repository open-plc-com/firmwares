/*
	Name:			mx_spi_mcp2515.c
	Purpose:		IO module
	Author:			open-plc.com
	Created:		2018/12
	Modified by:
	RCS-ID:
	Copyright:		(c) Open-PLC
	Licence:		The MIT License (MIT)
*/

#include "stm32f30x_spi.h"
#define TIMEOUT_TIME 20


// ===========================================================================
void delay_us_spi2( uint32_t delay )	// Delay in microseconds
// ===========================================================================
{
	volatile uint32_t i;
	i = delay * 6;
	for( ; i != 0; i-- ) {}
}
// ===========================================================================


// ===========================================================================
// Init SPI
// ===========================================================================
void Init_Spi( void )
{
	GPIO_InitTypeDef	GPIO_InitStructure;
	SPI_InitTypeDef		SPI_InitStructure;

	RCC_APB1PeriphClockCmd( RCC_APB1Periph_SPI2, ENABLE );	// Clocking SPI2
	GPIO_PinAFConfig( GPIOB, GPIO_PinSource13, GPIO_AF_5 );
	GPIO_PinAFConfig( GPIOB, GPIO_PinSource14, GPIO_AF_5 );
	GPIO_PinAFConfig( GPIOB, GPIO_PinSource15, GPIO_AF_5 );

	// --- SPI2 --------------------------------------------------------------
	/* SPI2 GPIO Configuration
	   PB12 --> SPI2_NSS
	   PB13 --> SPI2_SCK
	   PB14 <-- SPI2_MISO
	   PB15 --> SPI2_MOSI
	*/

	GPIO_StructInit( &GPIO_InitStructure );

	// SPI2_NSS
	GPIO_InitStructure.GPIO_Pin		= GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Speed	= GPIO_Speed_50MHz;
	//GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_OType	= GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_PuPd	= GPIO_PuPd_NOPULL;
	GPIO_Init( GPIOB, &GPIO_InitStructure );
	GPIO_SetBits( GPIOB, GPIO_Pin_12 );		// NSS Up

	GPIO_InitStructure.GPIO_Pin		= GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_PuPd	= GPIO_PuPd_DOWN;
	GPIO_Init( GPIOB, &GPIO_InitStructure );

	/* SPI configuration -------------------------------------------------------*/
	SPI_I2S_DeInit(SPI2);
	SPI_StructInit( &SPI_InitStructure );
	SPI_InitStructure.SPI_Direction				= SPI_Direction_2Lines_FullDuplex;	// Fullduplex mode
	SPI_InitStructure.SPI_DataSize				= SPI_DataSize_8b;					// Transfer 8 bits
	SPI_InitStructure.SPI_CPOL					= SPI_CPOL_Low;						// Polarity low
	SPI_InitStructure.SPI_CPHA					= SPI_CPHA_1Edge;					// The phase of the clock signal for the front
	SPI_InitStructure.SPI_NSS					= SPI_NSS_Soft;						// State of NSS signal - software control
	SPI_InitStructure.SPI_BaudRatePrescaler		= SPI_BaudRatePrescaler_32;			// Devider SCK
//	SPI_InitStructure.SPI_BaudRatePrescaler		= SPI_BaudRatePrescaler_64;
	SPI_InitStructure.SPI_FirstBit				= SPI_FirstBit_MSB;					// Is first send upper bit
	SPI_InitStructure.SPI_Mode					= SPI_Mode_Master;					// master mode
//	SPI_InitStructure.SPI_CRCPolynomial			= 7;
	SPI_Init( SPI2, &SPI_InitStructure );											// Initialize SPI2
	SPI_Cmd( SPI2, ENABLE );														// Switch on module SPI2
}
// ===========================================================================


/* ===========================================================================
   Read/Write data to SPIx
   use arrays spiX_tx_data[] and spiX_rx_data[]
   array size - SPI_LEN
   Work without interruption, so at the same time write and read.
   In read only mode send zeros for strobing. */
// ===========================================================================
void send_spi2( uint8_t cnt )
// ===========================================================================
{
	int		i, timeout;

	if( cnt > SPI_LEN )
	{
		cnt = SPI_LEN;
	}

	GPIO_ResetBits( GPIOB, GPIO_Pin_12 );	// NSS Down
	delay_us_spi2( 2 );

	for( i = 0; i < cnt; i++ )
	{
		timeout = TIMEOUT_TIME;
		while( ( SPI_I2S_GetFlagStatus( SPI2, SPI_I2S_FLAG_TXE ) == RESET) && timeout-- ) {}

		SPI_SendData8( SPI2, spi2_tx_data[i] );		// Send byte

		timeout = TIMEOUT_TIME;
		while( ( SPI_I2S_GetFlagStatus( SPI2, SPI_I2S_FLAG_RXNE ) == RESET ) && timeout-- ) {}

		spi2_rx_data[i] = SPI_ReceiveData8( SPI2 );		// Get byte
	}

	delay_us_spi2( 2 );
	GPIO_SetBits( GPIOB, GPIO_Pin_12 );		// NSS Up
	delay_us_spi2( 10 );
}
// ===========================================================================

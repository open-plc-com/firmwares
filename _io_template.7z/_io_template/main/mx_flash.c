/*
	Name:			mx_flash.c
	Purpose:		IO module
	Author:			open-plc.com
	Created:		2018/12
	Modified by:
	RCS-ID:
	Copyright:		(c) Open-PLC
	Licence:		The MIT License (MIT)
*/


// ===========================================================================
void Write_Flash( void )
// ===========================================================================
{
	uint32_t	i;
	uint16_t	j, k, l;
	uint16_t	*p_a, *p_b;
	double		f_a, f_b;

	p_a = (uint16_t*) &f_a;
	p_b = (uint16_t*) &f_b;

	// FLASH_Unlock
	FLASH->KEYR = FLASH_KEY1;
	FLASH->KEYR = FLASH_KEY2;

	// FLASH_Erase Page
	while( FLASH->SR&FLASH_SR_BSY ) {}
	FLASH->CR |= FLASH_CR_PER;			//Page Erase Set
	FLASH->AR = Page_127;				//Page Address
	FLASH->CR |= FLASH_CR_STRT;			//Start Page Erase
	while( FLASH->SR&FLASH_SR_BSY ) {}
	FLASH->CR &= ~FLASH_CR_PER;			//Page Erase Clear
	FLASH->CR |= FLASH_CR_PG;			// FLASH_Program HalfWord

	k = 0;
	i = DeviceType; j = i & 0xFFFF;
	while( FLASH->SR&FLASH_SR_BSY ) {}
	*( __IO uint16_t* ) ( Page_127 + k ) = j; k += 2;
	i = i >> 16; j = i & 0xFFFF;
	while( FLASH->SR&FLASH_SR_BSY ) {}
	*( __IO uint16_t* ) ( Page_127 + k ) = j; k += 2;

	i = Sn; j = i & 0xFFFF;
	while( FLASH->SR&FLASH_SR_BSY ) {}
	*( __IO uint16_t* ) ( Page_127 + k )= j; k += 2;
	i = i >> 16; j = i & 0xFFFF;
	while( FLASH->SR&FLASH_SR_BSY ) {}
	*( __IO uint16_t* ) ( Page_127 + k ) = j; k += 2;

	while( FLASH->SR&FLASH_SR_BSY ) {}
	*( __IO uint16_t* ) ( Page_127 + k ) = Noc; k += 2;

	while( FLASH->SR&FLASH_SR_BSY ) {}
	*( __IO uint16_t* ) ( Page_127 + k ) = Speedc; k += 2;

	while( FLASH->SR&FLASH_SR_BSY ) {}
	*( __IO uint16_t* ) ( Page_127 + k ) = Nn_Ch; k += 2;

	while( FLASH->SR&FLASH_SR_BSY ) {}
	*( __IO uint16_t* ) ( Page_127 + k ) = iButton_Timeout; k += 2;

	for( i = 0; i < MAX_NN_CH; i++ )
	{
		if( GPIO_X[i].gpio_x == GPIOA )
		{
			l = 1;
		}
		else
		if( GPIO_X[i].gpio_x == GPIOB )
		{
			l = 2;
		}
		else
		if( GPIO_X[i].gpio_x == GPIOC )
		{
			l = 3;
		}
		else
		{
			l = 0;
		}
		while( FLASH->SR&FLASH_SR_BSY ) {}
		*( __IO uint16_t* ) ( Page_127 + k ) = l; k += 2;

		l = GPIO_X[i].gpio_pin_nn;
		while( FLASH->SR&FLASH_SR_BSY ) {}
		*( __IO uint16_t* ) ( Page_127 + k ) = l; k += 2;

		l = GPIO_X[i].dev_type;
		while( FLASH->SR&FLASH_SR_BSY ) {}
		*( __IO uint16_t* ) ( Page_127 + k ) = l; k += 2;

		f_a = GPIO_X[i].adc_a;
		f_b = GPIO_X[i].adc_b;

		for( j = 0; j < 4; j++ )
		{
			l = p_a[j];
			while( FLASH->SR&FLASH_SR_BSY ) {}
			*( __IO uint16_t* ) ( Page_127 + k ) = l; k += 2;

			l = p_b[j];
			while( FLASH->SR&FLASH_SR_BSY ) {}
			*( __IO uint16_t* ) ( Page_127 + k ) = l; k += 2;
		}

		l = GPIO_X[i].adc_dc_ac;
		while( FLASH->SR&FLASH_SR_BSY ) {}
		*( __IO uint16_t* ) ( Page_127 + k ) = l; k += 2;
	}	// for( i = 0; i < Ch_Nn; i++ )

	while( ( FLASH->SR&FLASH_SR_BSY ) ) {}
	FLASH->CR &= ~FLASH_CR_PG;
	FLASH->CR |= FLASH_CR_LOCK;
}
// ===========================================================================


// ===========================================================================
void Read_Flash( void )
// ===========================================================================
{
	uint32_t			i, j;
	uint16_t			k, l;
	static uint32_t		*uid = ( uint32_t* ) 0x1FFFF7AC;
	uint16_t			*p_a, *p_b;
	double				f_a, f_b;

	k = 0;
	p_a = (uint16_t*) &f_a;
	p_b = (uint16_t*) &f_b;

	DeviceType		= *( uint32_t* ) ( Page_127 + k ); k += 4;
	Sn				= *( uint32_t* ) ( Page_127 + k ); k += 4;
	Noc				= *( uint16_t* ) ( Page_127 + k ); k += 2;
	Speedc			= *( uint16_t* ) ( Page_127 + k ); k += 2;
	Nn_Ch			= *( uint16_t* ) ( Page_127 + k ); k += 2;
	iButton_Timeout	= *( uint16_t* ) ( Page_127 + k ); k += 2;

	if( ( Nn_Ch > MAX_NN_CH ) || ( Nn_Ch == 0 ) )
	{
		Nn_Ch = 1;
	}

	for( i = 0; i < MAX_NN_CH; i++ )
	{
		l = *( uint16_t* ) ( Page_127 + k ); k += 2;

		if( l == 1 )
		{
			GPIO_X[i].gpio_x = GPIOA;
		}
		else
		if( l == 2 )
		{
			GPIO_X[i].gpio_x = GPIOB;
		}
		else
		if( l == 3 )
		{
			GPIO_X[i].gpio_x = GPIOC;
		}
		else
		{
			GPIO_X[i].gpio_x = 0;
		}

		l = *( uint16_t* ) ( Page_127 + k ); k += 2;
		if( l < MAX_NN_CH )
		{
			GPIO_X[i].gpio_pin_nn = l;
		}
		else
		{
			GPIO_X[i].gpio_x = 0;
			GPIO_X[i].gpio_pin_nn = 0;
		}

		for( j = 0; j < RESERVED_CH_NN; j++ )
		{
			if( ( GPIO_X[i].gpio_x == Reserved_Ch[j].gpio_x ) && ( GPIO_X[i].gpio_pin_nn == Reserved_Ch[j].gpio_pin_nn ) )
			{
				GPIO_X[i].gpio_x = 0;
				GPIO_X[i].gpio_pin_nn = 0;
			}
		}

		l = *( uint16_t* ) ( Page_127 + k ); k += 2;
		if( l <= MAX_DEV_TYPE )
		{
			GPIO_X[i].dev_type = l;
		}
		else
		{
			GPIO_X[i].dev_type = 0;
		}

		switch( GPIO_X[i].gpio_pin_nn )
		{
			case 0:		GPIO_X[i].gpio_pin_x	= GPIO_Pin_0;	break;
			case 1:		GPIO_X[i].gpio_pin_x	= GPIO_Pin_1;	break;
			case 2:		GPIO_X[i].gpio_pin_x	= GPIO_Pin_2;	break;
			case 3:		GPIO_X[i].gpio_pin_x	= GPIO_Pin_3;	break;
			case 4:		GPIO_X[i].gpio_pin_x	= GPIO_Pin_4;	break;
			case 5:		GPIO_X[i].gpio_pin_x	= GPIO_Pin_5;	break;
			case 6:		GPIO_X[i].gpio_pin_x	= GPIO_Pin_6;	break;
			case 7:		GPIO_X[i].gpio_pin_x	= GPIO_Pin_7;	break;
			case 8:		GPIO_X[i].gpio_pin_x	= GPIO_Pin_8;	break;
			case 9:		GPIO_X[i].gpio_pin_x	= GPIO_Pin_9;	break;
			case 10:	GPIO_X[i].gpio_pin_x	= GPIO_Pin_10;	break;
			case 11:	GPIO_X[i].gpio_pin_x	= GPIO_Pin_11;	break;
			case 12:	GPIO_X[i].gpio_pin_x	= GPIO_Pin_12;	break;
			case 13:	GPIO_X[i].gpio_pin_x	= GPIO_Pin_13;	break;
			case 14:	GPIO_X[i].gpio_pin_x	= GPIO_Pin_14;	break;
			case 15:	GPIO_X[i].gpio_pin_x	= GPIO_Pin_15;	break;
			default:	GPIO_X[i].gpio_pin_x	= 0;
		}

		for( j = 0; j < 4; j++ )
		{
			l = *( uint16_t* ) ( Page_127 + k ); k += 2;
			p_a[j] = l;

			l = *( uint16_t* ) ( Page_127 + k ); k += 2;
			p_b[j] = l;
		}
		l = *( uint16_t* ) ( Page_127 + k ); k += 2;
		GPIO_X[i].adc_dc_ac = l;
	}

	if( iButton_Timeout > 80 )
	{
		iButton_Timeout = 80;	// 10 sec
	}

	#ifdef DEV_TYPE
		DeviceType = DEV_TYPE;
	#endif

	#ifdef DEV_ID
		Sn = ( uid[0] ^ uid[2] );
		Sn8  = uid[0];
		Sn8  = Sn8 << 32;
		Sn8 |= uid[2];
	#endif
}
// ===========================================================================

/*
	Name:			mx_init.c
	Purpose:		IO module
	Author:			www.open-plc.com
	Created:		2018/12
	Modified by:
	RCS-ID:
	Copyright:		(c) Open-PLC
	Licence:		The MIT License (MIT)
*/


#include "mx_init.h"

// ===========================================================================
void MX_Init( void )
// ===========================================================================
{
	GPIO_InitTypeDef		GPIO_InitStructure;
	GPIO_TypeDef			*GPIOx;
	USART_InitTypeDef		USART_InitStructure;
	USART_ClockInitTypeDef	USART_ClockInitStructure;
	NVIC_InitTypeDef		NVIC_InitStructure;

	int				i, j, k, m, n;
	unsigned int	ui;
//	char			s[128];		// for print_str


	// -----------------------------------------------------------------------
	// Enable peripheral clock
	// -----------------------------------------------------------------------

	RCC_AHBPeriphClockCmd( RCC_AHBPeriph_GPIOA, ENABLE );				// Clocking GPIOA
	RCC_AHBPeriphClockCmd( RCC_AHBPeriph_GPIOB, ENABLE );				// Clocking GPIOB
	RCC_AHBPeriphClockCmd( RCC_AHBPeriph_GPIOC, ENABLE );				// Clocking GPIOC

//	RCC_APB2PeriphClockCmd( RCC_APB2Periph_SYSCFG, ENABLE );
//	RCC_APB2PeriphClockCmd( RCC_APB2Periph_AFIO, ENABLE );				// Clocking AF APB2


	// -----------------------------------------------------------------------
	// Start DWT
	// -----------------------------------------------------------------------
	#ifdef F_DWT
		SCB_DEMCR		|= 0x01000000;	// enable trace
		//DWT_LAR		 = 0xC5ACCE55;	// unlock access to DWT (ITM, etc.) registers; Cortex M3
		DWT_CONTROL		|= 1;			// enable DWT cycle counter
		DWT_CYCCNT		 = 0;			// clear DWT cycle counter
	#endif


	// -----------------------------------------------------------------------
	// Set Priority Group
	// -----------------------------------------------------------------------
	NVIC_PriorityGroupConfig( NVIC_PriorityGroup_3 );


	// -----------------------------------------------------------------------
	// Init GPIOS
	// -----------------------------------------------------------------------

	// Configure GPIO pin : PC13 ( LED blink )
	#ifdef LED_BLINK
		GPIO_StructInit( &GPIO_InitStructure );
		GPIO_InitStructure.GPIO_Pin		= GPIO_Pin_13;
		GPIO_InitStructure.GPIO_Speed	= GPIO_Speed_50MHz;
	//	GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_AF;
		GPIO_InitStructure.GPIO_OType	= GPIO_OType_PP;
		GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_OUT;
	//	GPIO_InitStructure.GPIO_PuPd	= GPIO_PuPd_NOPULL;
		GPIO_Init( GPIOC, &GPIO_InitStructure );
		GPIO_SetBits( GPIOC, GPIO_Pin_13 );		// Clear bit "blinking"
	#endif


//	#ifdef CAN_2515
////		GPIO_PinRemapConfig( GPIO_Remap_SWJ_Disable, ENABLE );
//		GPIO_StructInit( &GPIO_InitStructure );
//		GPIO_InitStructure.GPIO_Pin		= GPIO_Pin_5;
////		GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_IN_FLOATING;
//		GPIO_InitStructure.GPIO_Speed	= GPIO_Speed_50MHz;
//		GPIO_Init( GPIOB, &GPIO_InitStructure );
//	#endif


	// Configure GPIO pin : PB2 - BOOT1
//	GPIO_StructInit( &GPIO_InitStructure );
//	GPIO_InitStructure.GPIO_Pin		= GPIO_Pin_2;
//	GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_IN_FLOATING;
//	GPIO_InitStructure.GPIO_Speed	= GPIO_Speed_50MHz;
//	GPIO_Init( GPIOB, &GPIO_InitStructure );


	// -----------------------------------------------------------------------
	// Init MCO
	// -----------------------------------------------------------------------
	#ifdef MCO
		GPIO_InitStructure.GPIO_Pin		= GPIO_Pin_8;
		GPIO_InitStructure.GPIO_Speed	= GPIO_Speed_50MHz;
//		GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_AF;
		GPIO_InitStructure.GPIO_OType	= GPIO_OType_OD;
		GPIO_InitStructure.GPIO_PuPd	= GPIO_PuPd_UP;
		GPIO_Init( GPIOA, &GPIO_InitStructure );

		// HSE clock selected to output on MCO1 pin(PA8)
		RCC_MCOConfig( RCC_MCOSource_HSE );
		//RCC_MCOConfig( RCC_MCOSource_SYSCLK );
		//RCC_MCOConfig( RCC_MCOSource_PLLCLK );
	#endif

	// -----------------------------------------------------------------------
	// Init UARTS
	// -----------------------------------------------------------------------
	// USART1 Configuration
	// PA9		-> USART1_Tx
	// PA10		<- USART1_Rx
	#ifdef USE_UART1
		RCC_APB2PeriphClockCmd( RCC_APB2Periph_USART1, ENABLE );	// USART1 from PCLK2
		//RCC_USARTCLKConfig( RCC_USART1CLK_PCLK );					// Clocking USART1
		RCC_USARTCLKConfig( RCC_USART1CLK_SYSCLK );					// Clocking USART1

		// Configure GPIO AF
		GPIO_PinAFConfig( GPIOA, GPIO_PinSource9,  GPIO_AF_7 );
		GPIO_PinAFConfig( GPIOA, GPIO_PinSource10, GPIO_AF_7 );

		// Init GPIO
		GPIO_StructInit( &GPIO_InitStructure );
		GPIO_InitStructure.GPIO_Pin		=  GPIO_Pin_9 | GPIO_Pin_10;
		GPIO_InitStructure.GPIO_Speed	= GPIO_Speed_50MHz;
		GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_AF;
		GPIO_InitStructure.GPIO_OType	= GPIO_OType_PP;
		GPIO_InitStructure.GPIO_PuPd	= GPIO_PuPd_NOPULL;
		GPIO_Init( GPIOA, &GPIO_InitStructure );

		// Init UART1
		USART_DeInit( USART1 );
		USART_InitStructure.USART_BaudRate				= UART1_SPEED;
		USART_InitStructure.USART_WordLength			= USART_WordLength_8b;
		USART_InitStructure.USART_StopBits				= USART_StopBits_1;
		USART_InitStructure.USART_Parity				= USART_Parity_No;
		USART_InitStructure.USART_HardwareFlowControl	= USART_HardwareFlowControl_None;
		USART_InitStructure.USART_Mode					= USART_Mode_Rx | USART_Mode_Tx;
		USART_Init( USART1,&USART_InitStructure );

		// UART1 interrupt
		NVIC_InitStructure.NVIC_IRQChannel						= USART1_IRQn;	// Configure the USART1 interrupts
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority	= 2;			// Priority group of the USART1 interrupts
		NVIC_InitStructure.NVIC_IRQChannelSubPriority			= 1;			// Subpriority inside the group
		NVIC_InitStructure.NVIC_IRQChannelCmd					= ENABLE;		// The USART1 interrupts are globally enabled
		NVIC_Init( &NVIC_InitStructure );										// The properties are passed to the NVIC_Init function
		USART_ITConfig( USART1, USART_IT_RXNE, ENABLE );						// Enable the USART1 receive interrupt

		USART_Cmd( USART1, ENABLE );											// Finally this enables the complete USART1 peripheral

		USART_ClearITPendingBit( USART1, USART_IT_RXNE | USART_IT_TXE );		// Clear UART
		print_str( "+++\r\n" );
	#endif


	// -----------------------------------------------------------------------
	// Init PA*, PB*, PC*
	// -----------------------------------------------------------------------
	for( i = 0; i < 3; i++ )
	{
		switch( i )
		{
			case 0:
					GPIOx = GPIOA;
					break;
			case 1:
					GPIOx = GPIOB;
					break;
			case 2:
					GPIOx = GPIOC;
					break;
			default:
					break;
		}
		for( j = 1; j < 7; j++ )
		{
			ui = 0;
			for( k = 0; k < Nn_Ch; k++ )
			{
				if( ( GPIO_X[k].gpio_x == GPIOx ) && ( GPIO_X[k].dev_type == j ) )
				{
					ui |= GPIO_X[k].gpio_pin_x;
				}
			}
			if( ui )
			{
				GPIO_StructInit( &GPIO_InitStructure );
				GPIO_InitStructure.GPIO_Pin		= ui;
				GPIO_InitStructure.GPIO_Speed	= GPIO_Speed_50MHz;
				switch( j )
				{
					case 1:		// DS18B20
					case 2:		// iButton
					case 4:		// OD PullUp
							GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_OUT;
							GPIO_InitStructure.GPIO_OType	= GPIO_OType_OD;
							GPIO_InitStructure.GPIO_PuPd	= GPIO_PuPd_UP;
							break;
					case 3:		// PP
							GPIO_InitStructure.GPIO_OType	= GPIO_OType_PP;
							GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_OUT;
							GPIO_InitStructure.GPIO_PuPd	= GPIO_PuPd_NOPULL;
							break;
					case 5:		// OD PullDown
							GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_OUT;
							GPIO_InitStructure.GPIO_OType	= GPIO_OType_OD;
							GPIO_InitStructure.GPIO_PuPd	= GPIO_PuPd_DOWN;
							break;
					case 6:		// Unput Float
							GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_IN;
							//GPIO_InitStructure.GPIO_OType	= GPIO_OType_OD;
							GPIO_InitStructure.GPIO_PuPd	= GPIO_PuPd_NOPULL;
							break;
					default:
							break;
				}
				GPIO_Init( GPIOx, &GPIO_InitStructure );
			}
		}
	}

	for( i = 0; i < Nn_Ch; i++ )
	{
		if( ( GPIO_X[i].gpio_x == GPIOC ) && ( GPIO_X[i].gpio_pin_x == GPIO_Pin_13 ) )
		{
			GPIO_SetBits( GPIOC, GPIO_Pin_13 );
		}






	}











//--	// Init PA
//--	ui = 0;
//--	j = 0;
//--	for( i = 0; i < Nn_Ch; i++ )
//--	{
//--		if( GPIO_X[i].gpio_x == GPIOA )
//--		{
//--			if( ( GPIO_X[i].dev_type == 1 ) || \
//--				( GPIO_X[i].dev_type == 2 ) || \
//--				( GPIO_X[i].dev_type == 3 ) || \
//--				( GPIO_X[i].dev_type == 4 ) )
//--			{
//--				ui |= GPIO_X[i].gpio_pin_x;
//--				j = 1;
//--			}
//--		}
//--	}
//--
//--	if( j )
//--	{
//--		GPIO_StructInit( &GPIO_InitStructure );
//--		GPIO_InitStructure.GPIO_Pin		= ui;
//--		GPIO_InitStructure.GPIO_Speed	= GPIO_Speed_50MHz;
//--//		GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_AF;
//--		//GPIO_InitStructure.GPIO_OType	= GPIO_OType_PP;
//--		GPIO_InitStructure.GPIO_OType	= GPIO_OType_OD;
//--		GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_OUT;
//--//		GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_IN;
//--		GPIO_InitStructure.GPIO_PuPd	= GPIO_PuPd_UP;
//--		GPIO_Init( GPIOA, &GPIO_InitStructure );
//--	}
//--
//--	ui = 0;
//--	j = 0;
//--	for( i = 0; i < Nn_Ch; i++ )
//--	{
//--		if( GPIO_X[i].gpio_x == GPIOA )
//--		{
//--			if( GPIO_X[i].dev_type == 5 )
//--			{
//--				ui |= GPIO_X[i].gpio_pin_x;
//--				j = 1;
//--			}
//--		}
//--	}
//--
//--	if( j )
//--	{
//--		GPIO_StructInit( &GPIO_InitStructure );
//--		GPIO_InitStructure.GPIO_Pin		= ui;
//--		//GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_IN_FLOATING;
//--		GPIO_InitStructure.GPIO_Speed	= GPIO_Speed_50MHz;
//--		GPIO_Init( GPIOA, &GPIO_InitStructure );
//--	}
//--
//--//		// Init PB
//--//		ui = 0;
//--//		j = 0;
//--//		for( i = 0; i < Nn_Ch; i++ )
//--//		{
//--//			if( GPIO_X[i].gpio_x == GPIOB )
//--//			{
//--//				if( ( GPIO_X[i].dev_type == 1 ) || \
//--//					( GPIO_X[i].dev_type == 2 ) || \
//--//					( GPIO_X[i].dev_type == 3 ) || \
//--//					( GPIO_X[i].dev_type == 4 ) )
//--//				{
//--//					ui |= GPIO_X[i].gpio_pin_x;
//--//					j = 1;
//--//				}
//--//			}
//--//		}
//--//		if( j )
//--//		{
//--//			GPIO_InitStructure.GPIO_Pin		= ui;
//--//			GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_Out_PP;
//--//			GPIO_InitStructure.GPIO_Speed	= GPIO_Speed_50MHz;
//--//			GPIO_Init( GPIOB, &GPIO_InitStructure );
//--//		}
//--//		ui = 0;
//--//		j = 0;
//--//		for( i = 0; i < Nn_Ch; i++ )
//--//		{
//--//			if( GPIO_X[i].gpio_x == GPIOB )
//--//			{
//--//				if( GPIO_X[i].dev_type == 5 )
//--//				{
//--//					ui |= GPIO_X[i].gpio_pin_x;
//--//					j = 1;
//--//				}
//--//			}
//--//		}
//--//		if( j )
//--//		{
//--//			GPIO_InitStructure.GPIO_Pin		= ui;
//--//			GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_IN_FLOATING;
//--//			GPIO_InitStructure.GPIO_Speed	= GPIO_Speed_50MHz;
//--//			GPIO_Init( GPIOB, &GPIO_InitStructure );
//--//		}
//--
//--	// Set or reset pins PA & PB
//--	for( i = 0; i < Nn_Ch; i++ )
//--	{
//--		if( ( GPIO_X[i].gpio_x == GPIOA ) || ( GPIO_X[i].gpio_x == GPIOB ) )
//--		{
//--			if( GPIO_X[i].dev_type )
//--			{
//--				if( GPIO_X[i].dev_type == 3 )
//--				{
//--					GPIO_ResetBits( GPIO_X[i].gpio_x, GPIO_X[i].gpio_pin_x );	// Reset bit
//--				}
//--				else
//--				if( ( GPIO_X[i].dev_type == 1 ) || ( GPIO_X[i].dev_type == 2 ) || ( GPIO_X[i].dev_type == 4 ) )
//--				{
//--					GPIO_SetBits( GPIO_X[i].gpio_x, GPIO_X[i].gpio_pin_x );		// Set bit
//--				}
//--			}	// if( GPIO_X[i].dev_type )
//--		}	// if( GPIO_X[i].gpio_x == GPIOA )
//--	}	// for( i = 0; i < Nn_Ch; i++ )


//		// -----------------------------------------------------------------------
//		// PB3 - MCP2515 interrupt
//		// -----------------------------------------------------------------------
//		#ifdef CAN_2515
//			GPIO_PinRemapConfig( GPIO_Remap_SWJ_Disable, ENABLE );
//			GPIO_InitStructure.GPIO_Pin		= GPIO_Pin_3;
//			GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_IN_FLOATING;
//			GPIO_InitStructure.GPIO_Speed	= GPIO_Speed_2MHz;
//			GPIO_Init( GPIOB, &GPIO_InitStructure );
//		#endif


	// -----------------------------------------------------------------------
	// Init timers
	// SysTick_Config( SysyTick ) SysyTick - Number of ticks between two interrupts
	// -----------------------------------------------------------------------
	SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK);
	SysTick_Config( F_APB1 / ( 720 / 8 ) );		// interrupt 10 ms
	NVIC_InitStructure.NVIC_IRQChannel						= ( uint8_t ) SysTick_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority	= 5;
	//NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority	= 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority			= 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd					= ENABLE;
	NVIC_Init( &NVIC_InitStructure );


	// -----------------------------------------------------------------------
	// Start watchdog timer
	// -----------------------------------------------------------------------
	#ifdef WD_TIMER
		IWDG_WriteAccessCmd( IWDG_WriteAccess_Enable );
		IWDG_SetPrescaler( IWDG_Prescaler_32 );
		IWDG_SetReload( 40000 / 128 );								// 312 ms
		IWDG_ReloadCounter();
		IWDG_Enable();
	#endif


	// -----------------------------------------------------------------------
	// Init global variables
	// -----------------------------------------------------------------------
	CntTime			= 0;		// SysTick count
	DelayTime		= 0;
	CntTime_1ms		= 0;
	ret_button		= FALSE;	// Press "Enter"?
	cli_mode		= FALSE;	// CLI mode
	//read_data_mode	= FALSE;	// Read Data mode ( for ADC setup )
	NoAnswer		= FALSE;	// No answer in CAN broadcast
	CANDownTime		= 0;
	CAN_Run			= FALSE;
	Echo			= TRUE;
	Step_DS			= 0;
	Step_BTN		= 0;
	lc1				= CntTime;
	lc3				= CntTime;
	lc2				= CntTime;
	lc_1ms			= CntTime_1ms;

//		for( i = 0; i < ADC_ARRAY_SIZE; i++ )
//		{
//			ADC_VALUES[i] = 0xFFFF;
//		}
//
//		for( i = 0; i < USER_DATA_NN; i++ )
//		{
//			User_Data[i].data	= 0;
//			User_Data[i].in_use	= FALSE;
//		}
//
//	//	for( i = 0; i < MAX_NN_CH; i++ )
//	//	{
//	//		Reserved_Ch[i].gpio_x		= 0;
//	//		Reserved_Ch[i].gpio_pin_nn	= 0;
//	//	}
}
// ===========================================================================

/*
	Name:			mx_adc.c
	Purpose:		IO module
	Author:			www.open-plc.com; e-mail: info@open-plc.com
	Created:		2018/07
	Modified by:
	RCS-ID:
	Copyright:		(c) Open-PLC
	Licence:		The MIT License (MIT)
*/


//============================================================================
void Init_ADC(void)
// ===========================================================================
{
	GPIO_InitTypeDef			GPIO_InitStructure;
	ADC_InitTypeDef				ADC_InitStructure;
	DMA_InitTypeDef				DMA_InitStructure;

	// Enable ADC1 and DMA clock
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_ADC1 | RCC_APB2Periph_AFIO, ENABLE );	// Clocking ADC1
	RCC_AHBPeriphClockCmd( RCC_AHBPeriph_DMA1, ENABLE );							// Clocking DMA1
	//ADC_TempSensorVrefintCmd( ENABLE );

//	GPIO_InitStructure.GPIO_Pin		= GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Pin		= GPIO_Pin_2 | GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_AIN;
	GPIO_InitStructure.GPIO_Speed	= GPIO_Speed_50MHz;
	GPIO_Init( GPIOA, &GPIO_InitStructure );

	// Start DMA
	DMA_DeInit( DMA1_Channel1 );
	DMA_InitStructure.DMA_BufferSize			= ADC_ARRAY_SIZE;
	DMA_InitStructure.DMA_DIR					= DMA_DIR_PeripheralSRC;
	DMA_InitStructure.DMA_M2M					= DMA_M2M_Disable;
	DMA_InitStructure.DMA_MemoryBaseAddr		= ( uint32_t ) ADC_VALUES;
	DMA_InitStructure.DMA_MemoryDataSize		= DMA_MemoryDataSize_HalfWord;
	DMA_InitStructure.DMA_MemoryInc				= DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_Mode					= DMA_Mode_Circular;
	DMA_InitStructure.DMA_PeripheralBaseAddr	= ( uint32_t ) &ADC1->DR;
	DMA_InitStructure.DMA_PeripheralDataSize	= DMA_PeripheralDataSize_HalfWord;
	DMA_InitStructure.DMA_PeripheralInc			= DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_Priority				= DMA_Priority_High;
	DMA_Init( DMA1_Channel1, &DMA_InitStructure );
	DMA_Cmd( DMA1_Channel1, ENABLE );

	// Start ADC
	ADC_DeInit( ADC1 );
	ADC_StructInit( &ADC_InitStructure );
	ADC_InitStructure.ADC_ContinuousConvMode	= ENABLE;
	ADC_InitStructure.ADC_DataAlign				= ADC_DataAlign_Right;
	ADC_InitStructure.ADC_ExternalTrigConv		= ADC_ExternalTrigConv_None;
	ADC_InitStructure.ADC_Mode					= ADC_Mode_Independent;
	ADC_InitStructure.ADC_NbrOfChannel			= 2;
	ADC_InitStructure.ADC_ScanConvMode			= ENABLE;
	ADC_Init( ADC1, &ADC_InitStructure );
	/*
		The total conversion time is calculated as follows:
		Tconv = Sampling time + 12.5 cycles
		Example:
		With an ADCCLK = 14 MHz and a sampling time of 1.5 cycles:
		Tconv = 1.5 + 12.5 = 14 cycles = 1 us
		Configure a sampling time of channel ( 1.5, 7.5, 13.5, 28.5, 41.5, 55.5, 71.5, 239.5 )
	*/
	ADC_RegularChannelConfig( ADC1, ADC_Channel_2, 1, ADC_SampleTime_239Cycles5 );
	ADC_RegularChannelConfig( ADC1, ADC_Channel_3, 2, ADC_SampleTime_239Cycles5 );
//	ADC_RegularChannelConfig( ADC1, ADC_Channel_TempSensor, 1, ADC_SampleTime_71Cycles5 );
//	ADC_RegularChannelConfig( ADC1, ADC_Channel_16, 1, ADC_SampleTime_239Cycles5 );
	//ADC_RegularChannelConfig(ADC1, ADC_Channel_7, 4, ADC_SampleTime_7Cycles5);

	ADC_Cmd( ADC1, ENABLE );
	ADC_DMACmd( ADC1, ENABLE );
	ADC_ResetCalibration( ADC1 );
	while( ADC_GetResetCalibrationStatus( ADC1 ) );
	ADC_StartCalibration( ADC1 );
	while( ADC_GetCalibrationStatus( ADC1 ) );
	ADC_SoftwareStartConvCmd( ADC1 , ENABLE );
}
// ===========================================================================

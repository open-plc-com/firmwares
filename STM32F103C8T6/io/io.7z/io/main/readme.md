Use bsp_def.h for configure

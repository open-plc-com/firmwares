#ifndef __mx_init_H
#define __mx_init_H

#ifdef __cplusplus
	extern "C" {
#endif

#include <misc.h>

void MX_Init( void );

#ifdef __cplusplus
}
#endif

#endif /* __mx_init_H */

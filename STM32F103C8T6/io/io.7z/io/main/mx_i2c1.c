/*
	Purpose:		IO module
	Author:			www.open-plc.com; e-mail: info@open-plc.com
	Created:		2018/07
	Modified by:
	RCS-ID:
	Copyright:		(c) Open-PLC
	Licence:		The MIT License (MIT)
*/

#ifdef LCD_1602

I2C_InitTypeDef			i2c1;
static volatile int		I2C1_ERR = 0;

// ===========================================================================
void init_I2C1( void )
// ===========================================================================
{
	GPIO_InitTypeDef	i2c_gpio;

	RCC_APB1PeriphClockCmd( RCC_APB1Periph_I2C1, ENABLE );

	// --- I2C1 ---
	// PB6 - SCL
	// PB7 - SDA
	i2c_gpio.GPIO_Pin				= GPIO_Pin_6 | GPIO_Pin_7;
	i2c_gpio.GPIO_Mode				= GPIO_Mode_AF_OD;
	i2c_gpio.GPIO_Speed				= GPIO_Speed_50MHz;
	GPIO_Init( GPIOB, &i2c_gpio );

	i2c1.I2C_ClockSpeed				= 100000;
	i2c1.I2C_Mode					= I2C_Mode_I2C;
	i2c1.I2C_DutyCycle				= I2C_DutyCycle_2;
	i2c1.I2C_OwnAddress1			= 0;
	i2c1.I2C_Ack					= I2C_Ack_Enable;
	i2c1.I2C_AcknowledgedAddress	= I2C_AcknowledgedAddress_7bit;
	I2C_Init( I2C1, &i2c1 );

	I2C_Cmd( I2C1, ENABLE );
}
// ===========================================================================


// ===========================================================================
int I2C_StartTransmission( I2C_TypeDef *I2Cx, uint8_t transmissionDirection, uint8_t slaveAddress )
// ===========================================================================
{
	uint32_t	lc;

	if( I2C1_ERR < 3 )
	{
		if( I2C1_ERR )
		{
			I2C_GenerateSTOP( I2Cx, ENABLE );
		}
		
		lc = CntTime;
		while( I2C_GetFlagStatus( I2Cx, I2C_FLAG_BUSY ) )
		{
			if( ( CntTime - lc ) > 20 ) { I2C1_ERR++; return 1; }
		}
		lc = CntTime;
		I2C_GenerateSTART( I2Cx, ENABLE );
		while( !I2C_CheckEvent( I2Cx, I2C_EVENT_MASTER_MODE_SELECT ) )
		{
			if( ( CntTime - lc ) > 20 ) { I2C1_ERR++; return 2; }
		}
		I2C_Send7bitAddress( I2Cx, ( slaveAddress << 1 ), transmissionDirection );

		if( transmissionDirection == I2C_Direction_Transmitter )
		{
			lc = CntTime;
			while( !I2C_CheckEvent( I2Cx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED ) )
			{
				if( ( CntTime - lc ) > 20 ) { I2C1_ERR++; return 3; }
			}
		}
		else
		if( transmissionDirection == I2C_Direction_Receiver )
		{
			lc = CntTime;
			while( !I2C_CheckEvent( I2Cx, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED ) )
			{
				if( ( CntTime - lc ) > 20 ) { I2C1_ERR++;  return 4; }
			}
		}
		I2C1_ERR = 0; return 0;
	}
	return 0;
}
// ===========================================================================


// ===========================================================================
int I2C_WriteData( I2C_TypeDef *I2Cx, uint8_t data )
// ===========================================================================
{
	uint32_t	lc;

	if( !I2C1_ERR )
	{
		lc = CntTime;
		I2C_SendData( I2Cx, data );
		while( !I2C_CheckEvent( I2Cx, I2C_EVENT_MASTER_BYTE_TRANSMITTED ) )
		{
			if( ( CntTime - lc ) > 20 ) { I2C1_ERR++; return 1; }
		}
		I2C1_ERR = 0; return 0;
	}
	return 0;
}
// ===========================================================================


// ===========================================================================
uint8_t I2C_ReadData( I2C_TypeDef *I2Cx )
// ===========================================================================
{
	uint32_t	lc;
	uint8_t		data;

	if( !I2C1_ERR )
	{
		lc = CntTime;
		lc = CntTime;
		data = I2C_ReceiveData( I2Cx );
		while( !I2C_CheckEvent( I2Cx, I2C_EVENT_MASTER_BYTE_RECEIVED ) )
		{
			if( ( CntTime - lc ) > 20 ) { I2C1_ERR++; return 1; }
		}
		return data;
	}
	return 0;
}
// ===========================================================================
#endif

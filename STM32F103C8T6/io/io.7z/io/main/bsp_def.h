#ifndef BSP_DEF
#define BSP_DEF
/* ======================================================================== */

#define USE_UART1
#define LED_BLINK	// PC13 LED blink
#define LCD_1602	// Use LCD 1602
#define PCF8574A	// I2C chip PCF8574 (PCF8574T) or PCF8574A (PCF8574AT)
#define USB_VCP		// Use USB as VCP
#define VCP_CONS	// USB VCP as Console
//#define CAN_2515	// Use CAN MCP2515

/* ======================================================================== */
#endif

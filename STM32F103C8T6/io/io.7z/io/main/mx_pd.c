#define PD_NN		3
struct Program_Data_Struct
{
	char		name[10];
	uint64_t	data;
	char		comment[34];
	char		data_type;		// c-char; i-int64_t; u-uint64_t (raw); f-float (double)
}	volatile	PD[PD_NN];

//int write_data( char *name, int64_t val )
//{

//}
//int write_pd_data( char *name, uint64_t val )
//{

//}



//strcpy( (char*) PD[0].name, "00000001" ); PD[0].data = 1; strcpy( (char*) PD[0].comment, "Comment #1" );
//strcpy( (char*) PD[1].name, "00000002" ); PD[0].data = 2; strcpy( (char*) PD[0].comment, "Comment #2" );
//strcpy( (char*) PD[2].name, "00000003" ); PD[0].data = 3; strcpy( (char*) PD[0].comment, "Comment #3" );

#ifndef __GBL__
#define __GBL__

#ifdef __cplusplus
	extern "C" {
#endif

// ---------------------------------------------------------------------------
#include "bsp_def.h"
// ---------------------------------------------------------------------------

#ifndef TRUE
	#define TRUE	1
#endif
#ifndef FALSE
	#define FALSE	0
#endif

#define VER					"\r\nIO module v1.5 (open-plc.com)\r\n"
#define DEV_TYPE			10000								// Device type
#define DEV_ID													// Device S/N 32 bits as S/N of microcontroller

#define WD_TIMER												// Switch on WatchDog
//#define OSC_INT												// Use internal oscillator
//#define F_APB1			24000000							// Sys frequency in Hz
//#define F_APB1			48000000							// Sys frequency in Hz
#define F_APB1				72000000							// Sys frequency in Hz
#ifndef F_APB1
	#define F_APB1			0
#endif
#define F_DWT				( F_APB1 / 1000000 )
//#define DWT

#define Page_63				0x0800FC00							// Page for param saving

#define UART1_SPEED			115200								// UART1 speed
#define RX_LEN				64									// Size of buffer UART Rx
#define SPI_LEN				24									// Size of buffer SPI

#define MAX_NN_CH			16									// Maximum number of channels
#define MAX_DEV_TYPE		6									// Maximum number of device type
#define MAX_W1_ERR			5									// Maximum continuing error counter
#define SHOW_DATA_INTERVAL	50									// 10 * SHOW_DATA_INTERVAL mSec

#define DWT_CYCCNT			*( volatile uint32_t* ) 0xE0001004
#define DWT_CONTROL			*( volatile uint32_t* ) 0xE0001000
#define SCB_DEMCR			*( volatile uint32_t* ) 0xE000EDFC
#define DWT_LAR				*( volatile uint32_t* ) 0xE0001FB0

static volatile uint32_t	DeviceType;							// Device type
static volatile uint32_t	Sn;									// Serial number (SN)
static volatile uint64_t	Sn8;								// Serial number (SN8)
static volatile uint16_t	Noc;								// CAN number
static volatile uint16_t	Speedc;								// CAN speed
static volatile bool		NoAnswer;							// Not answer for broadcast SN
static volatile bool		CanErr;

static volatile uint8_t		rx_idx;								// Index in UART recieve buffer
static volatile bool		ret_button;							// Return is pressed
static volatile bool		cli_mode;							// CLI mode
static volatile char		usart_rx_data[RX_LEN];				// recieve buffer data
static volatile char		cli_data[16];						// CLI prompt
static volatile uint32_t	UART1_Speed;

static volatile uint32_t	CntTime;							// Counter of quants of System Timer 10 ms
static volatile uint32_t	CntTime_1ms;						// Counter of quants of TIM4_IRQHandler 1 ms
static volatile uint32_t	DelayTime;							// For LED blink
static volatile uint32_t	WD_Time;							// Time of watchdog
static volatile uint32_t	CANDownTime;
static volatile bool		CAN_Run;

static volatile uint8_t		spi2_tx_data[SPI_LEN];				// Buffer of Tx SPI2
static volatile uint8_t		spi2_rx_data[SPI_LEN];				// Buffer of Rx SPI2

static volatile uint8_t		can_id[4];							// Header of CAN packet
static volatile uint8_t		can_data[8];						// CAN data

static volatile uint16_t	Nn_Ch;								// Number of channels
static volatile uint16_t	Nn_ADC;								// Number of ADC channels
static volatile uint16_t	iButton_Timeout;
static volatile uint16_t	Show_Data;
static volatile bool		Echo;

struct GPIO_Struct
{
	GPIO_TypeDef	*gpio_x;		// GPIO_X (Port)
	uint16_t		gpio_pin_nn;	// Pin Nn
	uint16_t		gpio_pin_x;		// GPIO_Pin_x
	uint16_t		dev_type;		// Device type: 1 - DS18B20
									//				2 - iButton
									//				3 - GPIO pull Down
									//				4 - GPIO pull Up
									//				6 - ADC
	uint64_t		raw_data;		// Raw data
	uint16_t		err;			// 1-Wire continuous error count
	uint16_t		ibutton_time;	// The rest of the time for remember the value iButton
	double			adc_a;			// factor "a" of equation y=a*x+b
	double			adc_b;			// factor "b" of equation y=a*x+b
	uint16_t		adc_dc_ac;		// 1=DC; 2=AC
} GPIO_Data;

struct GPIO_Struct	GPIO_X[MAX_NN_CH];

#define RESERVED_CH_NN	37			// Max for 48 pins chip
struct Reserved_Ch_Struct
{
	GPIO_TypeDef	*gpio_x;
	uint16_t		gpio_pin_nn;
}   Reserved_Ch[RESERVED_CH_NN] =
        {
			{ GPIOB, 2  },			// BOOT2 JUMPER
			#ifdef USE_UART1
				{ GPIOA, 9  },		// UART1_TX
				{ GPIOA, 10 },		// UART1_RX
			#endif
			#ifdef USB_VCP
				{ GPIOA, 11 },		// USB_DM
				{ GPIOA, 12 },		// USB_DP
			#endif
			#ifdef CAN_2515
				{ GPIOB, 3  },		// CAN_INT/
				{ GPIOB, 12 },		// SPI2_NSS
				{ GPIOB, 13 },		// SPI2_SCK
				{ GPIOB, 14 },		// SPI2_MISO
				{ GPIOB, 15 },		// SPI2_MOSI
			#endif
			#ifndef I2C1
				{ GPIOB, 6 },		// I2C1_SCL
				{ GPIOB, 7 },		// I2C1_SDA
			#endif
			#ifdef LED_BLINK
				{ GPIOC, 13 },		// PC13 LED blink
			#endif
		};

//#define USER_DATA_NN		16
//struct User_Data_Struct
//{
	//uint64_t	data;
	//bool		in_use;
//}	static volatile User_Data[USER_DATA_NN];

#define ADC_ARRAY_SIZE		500
static volatile uint16_t	ADC_VALUES[ADC_ARRAY_SIZE];

static volatile uint32_t	lc1, lc2, lc3, lc_1ms;
static volatile uint32_t	Step_DS;
static volatile uint32_t	Step_BTN;

static volatile uint32_t	ADCV;
static volatile uint32_t	ADCV1;
static volatile uint32_t	ADCV2;

#ifdef __cplusplus
	}
#endif

#endif /* __GBL__ */

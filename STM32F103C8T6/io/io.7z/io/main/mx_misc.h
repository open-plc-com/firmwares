#ifndef __mx_misc_H
#define __mx_misc_H

#ifdef __cplusplus
	extern "C" {
#endif

void sys_delay_ms( uint32_t delay );
void sys_delay_us( uint32_t delay );

#ifdef __cplusplus
}
#endif

#endif /* __mx_misc_H */
